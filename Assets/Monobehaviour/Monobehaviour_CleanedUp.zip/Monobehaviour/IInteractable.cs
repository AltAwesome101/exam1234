using UnityEngine;
public interface IInteractable
{
    void PlayerInteraction();

}
