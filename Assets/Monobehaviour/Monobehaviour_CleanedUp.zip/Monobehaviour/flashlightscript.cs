using UnityEngine;
using UnityEngine.Rendering.Universal;

public class flashlightscript : MonoBehaviour
{
    [SerializeField] private Light2D lightFlash;

    [SerializeField] private Material shaderMaterial;

    [SerializeField] private float maxDepth = 1f;

    [SerializeField] private float minDepth = 0f;
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.F))
        {

            lightFlash.enabled = !lightFlash.enabled;

            if (!lightFlash.enabled)
            {
                shaderMaterial.SetFloat("_Depth", maxDepth);
            }
            else
            {
                shaderMaterial.SetFloat("_Depth", minDepth);
            }

        }
    }
}
